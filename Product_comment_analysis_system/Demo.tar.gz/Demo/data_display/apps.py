from django.apps import AppConfig


class DataDisplayConfig(AppConfig):
    name = 'data_display'
